// Lấy phần tử toggle từ DOM
const toggle = document.getElementById('toggle-switch');
const extension = typeof browser !== 'undefined' ? browser : chrome;

// Khi trạng thái của toggle thay đổi (chuyển qua lại giữa ON/OFF)
toggle.addEventListener('change', function () {
    const isChecked = toggle.checked; // Kiểm tra xem toggle có được bật hay không
    // Lưu trạng thái của toggle vào chrome.storage để lưu trữ dữ liệu
    extension.storage.sync.set({ toggleState: isChecked }, function () {
        console.log('Toggle state saved:', isChecked); // Ghi log khi trạng thái đã được lưu
    });
});

// Tìm phần tử mũi tên (nút đóng popup)
const closeButton = document.querySelector('.close-btn');

// Lắng nghe sự kiện click vào mũi tên để đóng popup
closeButton.addEventListener('click', function () {
    window.close(); // Đóng popup khi nhấn vào mũi tên
});



// Khi popup được mở, đọc trạng thái toggle từ chrome.storage
extension.storage.sync.get('toggleState', function (data) {
    // Nếu không có trạng thái lưu trước đó (lần đầu mở popup), mặc định là false
    toggle.checked = data.toggleState !== undefined ? data.toggleState : false;
});

document.querySelectorAll('.footer button').forEach(button => {
    const icon = button.querySelector('i');
    if (!icon) return;
    let url = null;
    if (icon.classList.contains('fa-github')) url = 'https://github.com/Erik9910x';
    if (icon.classList.contains('fa-facebook')) url = 'https://facebook.com/erik9910';
    if (url) {
        button.addEventListener('click', () => extension.tabs.create({ url }));
    }
});
